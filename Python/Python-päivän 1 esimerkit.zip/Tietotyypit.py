luku = 123
teksti = "ABC"
print(type(teksti))

luku_tekstinä = "123"

if (luku == luku_tekstinä):
    print("Täsmää!")
else:
    print("Ei täsmää.")

teksti = 987
print("Loppu.")

print(type(luku))



print(type(teksti))
print(teksti.__class__)
