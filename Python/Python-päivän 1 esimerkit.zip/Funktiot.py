def muutaLista(lista):
   lista = [1,2,3,4]
   print("Listan sisältö funktion sisällä: ", lista)
   return

lista = [10,20,30]
muutaLista(lista)
print("Listan sisältö funktion ulkopuolella: ", lista)

lista2 = [1,2,3]
print(lista2)
lista3 = range(3)
print(lista3)