lyhyt = "ABC"
pitkä = """Rivi 1
Rivi 2
Rivi 3"""

print(type(lyhyt))
print(type(pitkä))


polku = r"C:\temp\tiedosto.txt"
print(polku)


m1 = "TESTI"
m2 = "TÄMÄ"
teksti = f"{m2} ON {m1}"

print(teksti)
