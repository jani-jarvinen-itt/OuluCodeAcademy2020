print("Hello World!")

luku = 1234
if (luku > 1000):
    print("Luku on yli tuhat")
    print("Rivi 1")
    print("Rivi 2")

else:
    print("Luku on tuhatta pienempi")
