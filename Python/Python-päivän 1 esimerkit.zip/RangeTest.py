for i in range(10):
    print(i)

luvut = range(50)
print(luvut)


laskuri = 1
while (laskuri < 10):
print("Ei toimi.")
