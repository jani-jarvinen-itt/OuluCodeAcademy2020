def sano_moi():
    print("Moi!")

def sano_hei():
    print("Hei!")
