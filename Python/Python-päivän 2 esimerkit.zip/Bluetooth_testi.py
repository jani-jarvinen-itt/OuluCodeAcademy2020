from PyBluez import *

print("Testi")
