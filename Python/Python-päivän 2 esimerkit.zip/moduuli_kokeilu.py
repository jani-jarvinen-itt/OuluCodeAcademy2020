from rutiineja import sano_moi, sano_hei

sano_moi()
sano_hei()
